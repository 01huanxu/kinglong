/* $Id: BullseyeCoverage.h.in 12210 2011-08-11 01:15:00Z Steve Cornett $
 * Copyright (c) Bullseye Testing Technology
 */
#undef _BullseyeCoverage
#define _BullseyeCoverage 8939

#if defined(__cplusplus)
extern "C" {
#endif

#if defined(_MSC_VER) || defined(__BORLANDC__)
	#define _Linkage __cdecl
#else
	#define _Linkage
#endif

int _Linkage cov_check(void);
unsigned _Linkage cov_eventCount(void);
int _Linkage cov_dumpData(void);
int _Linkage cov_file(const char*);
int _Linkage cov_reset(void);
void _Linkage cov_term(void);
int _Linkage cov_write(void);

#undef _Linkage

#if defined(__cplusplus)
}
#endif
