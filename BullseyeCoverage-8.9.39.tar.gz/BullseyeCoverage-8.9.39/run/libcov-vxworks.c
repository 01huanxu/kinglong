// $Revision: 14497 $ $Date: 2014-02-21 08:54:11 -0800 (Fri, 21 Feb 2014) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for VxWorks

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include "atomic.h"
#include "libcov.h"
#include "stub-getpid.h"
#include "version.h"
#define Libcov_prefix "/tgtsvr/"
#include "libcov-core-small.h"
