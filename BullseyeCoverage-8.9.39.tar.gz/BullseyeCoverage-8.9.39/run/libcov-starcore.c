/* $Revision: 14428 $ $Date: 2014-01-30 16:51:42 -0800 (Thu, 30 Jan 2014) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 *
 * BullseyeCoverage small footprint run-time definitions for Freescale StarCore
 */

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#define S_IRUSR 0x0100
#define S_IWUSR 0x0080
#define _ABI_2_0
#include <stdio.h>
#include "stub-getpid.h"

#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "libcov-core-small.h"
