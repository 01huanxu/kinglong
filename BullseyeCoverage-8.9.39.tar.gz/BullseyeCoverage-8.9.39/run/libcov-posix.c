/* $Revision: 14958 $ $Date: 2014-07-10 15:07:51 -0700 (Thu, 10 Jul 2014) $
 * Copyright (c) Bullseye Testing Technology
 * This source file contains confidential proprietary information.
 *
 * BullseyeCoverage run-time definitions for Unix-like operating systems
 */

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#if __GNUC__
	#define _GNU_SOURCE 1
#endif
#if __GNUC__ * 100 + __GNUC_MINOR__ >= 405
	#pragma GCC diagnostic ignored "-Wunused-result"
#endif
#if __sun
	#define _POSIX_C_SOURCE 199506L
#endif

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#if !Libcov_noAutoSave
	#include <pthread.h>
#endif
#include "cmn-getenvFile.h"

#if __linux && !__BIONIC__
	/* Shared pthread library might not be initialized early enough */
	#define isReady() (__errno_location() != NULL)
#endif

/* getenv */
static char* Libcov_getenv(const char* name)
{
	char* value = getenv(name);
	const int errnoSave = errno;
	if (value == NULL) {
		value = getenvFile(name, "/tmp/BullseyeCoverageEnv.txt");
	}
	if (value == NULL) {
		value = getenvFile(name, "/etc/BullseyeCoverageEnv.txt");
	}
	errno = errnoSave;
	return value;
}
#define getenv Libcov_getenv

/* There is a bug in glibc < 2.5 (mid-2006) which causes a crash if
// we call pthread_exit() in a shared object that is being unloaded */
#define pthread_exit(x)

/* open */
static int Libcov_open(const char *path, int oflag, int mode)
{
	/* If we get a standard descriptor 0, 1, 2, keep calling trying until we get a descriptor >= 3, or we tried 4 times. */
	int fd;
	int fdList[4];
	unsigned fdList_n = 0;
	unsigned i;
	do {
		fd = open(path, oflag, mode);
		fdList[fdList_n++] = fd;
	} while (fd >= 0 && fd <= 2 && fdList_n < 4);
	/*   Close the standard descriptors */
	fdList_n--;
	for (i = 0; i < fdList_n; i++) {
		close(fdList[i]);
	}
	return fd;
}
#define open Libcov_open

/* write */
static ssize_t Libcov_write(int fildes, const void* buf, size_t nbyte)
{
	ssize_t status;
	#if __GLIBC__ && !__UCLIBC__
		const char prefix[] = "BullseyeCoverage ";
		/* If this looks like an error message from our run-time */
		if (fildes == 2 && nbyte > sizeof("BullseyeCoverage n.n.n error nn: message") &&
			memcmp(buf, prefix, sizeof(prefix) - 1) == 0)
		{
			/* Append the name of the executable to the message */
			status = write(fildes, buf, nbyte - 1);
			static const char s[] = ". Executable is ";
			write(2, s, sizeof(s) - 1);
			size_t length;
			for (length = 0; program_invocation_short_name[length] != '\0'; length++)
				;
			write(2, program_invocation_short_name, length);
			write(2, "\n", 1);
		} else {
			status = write(fildes, buf, nbyte);
		}
	#else
		status = write(fildes, buf, nbyte);
	#endif
	return status;
}
#define write Libcov_write

#if __HP_cc
	#pragma INIT "cov_countUp"
	#pragma FINI "cov_countDown"
	#define atexit(x) 0
#endif
#if  __QNXNTO__
	/* Avoid ateixt on QNX 6.6. The atexit handling crashes upon dlclose */
	void cov_countDown(void) __attribute__((destructor));
	void cov_countUp(void) __attribute__((constructor));
	#define atexit(x) 0
#endif

#define Libcov_posix 1
#include "atomic.h"
#include "libcov.h"
#if __GNUC__ >= 4 && (__APPLE__ || __linux || __QNXNTO__)
	/* This pragma is supported by GCC 4.0 and later, but was not documented until 4.2 */
	#pragma GCC visibility push(hidden)
#endif
#include "cmn-autoSave.h"
#include "libcov-core-big.h"
