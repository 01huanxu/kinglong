// $Revision: 14428 $ $Date: 2014-01-30 16:51:42 -0800 (Thu, 30 Jan 2014) $
// Copyright (c) Bullseye Testing Technology
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time definitions for NXP TriMedia Compilation System

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <stddef.h>
#include <sys/fcntlcom.h>
#include <unistd.h>
#define S_IRUSR 0
#define S_IWUSR 0

#define open Libcov_open
int open(const char* path, int oflag, int mode)
{
	return _open(path, oflag | O_BINARY, mode);
}

#include "stub-getpid.h"
#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "libcov-core-small.h"
