/* $Revision: 14676 $
// Copyright (c) Bullseye Testing Technology
// Copyright (c) Qualcomm
// This source file contains confidential proprietary information.
//
// BullseyeCoverage small footprint run-time for UEFI
*/

#if _BullseyeCoverage
	#pragma BullseyeCoverage off
#endif

#include <Uefi.h>
#include <Library/DebugLib.h>

#define O_CREAT 0
#define O_TRUNC 0
#define O_WRONLY 0
#define S_IRUSR 0
#define S_IWUSR 0

typedef int ssize_t;

static int open(const char* path, int oflag, int mode)
{
	DEBUG(EFI_D_WARN, "--- BullseyeCoverage begin file '%a' ---\n", path);
	return 3;
}

static int close(int fildes)
{
	DEBUG(EFI_D_WARN, "--- BullseyeCoverage end of file ---\n");
	return 0;
}

static int write(int fildes, const void* buf, unsigned nbyte)
{
	DEBUG(EFI_D_WARN, "%a", buf);
	return (int)nbyte;
}

#include "atomic.h"
#include "libcov.h"
#include "version.h"
#include "stub-getpid.h"
#include "libcov-core-small.h"
